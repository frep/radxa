#undef LOCK
#define LOCK		ML

#undef UNLOCK
#define UNLOCK		MU

#undef RLOCK
#undef WLOCK

#undef INIT
#define INIT		MI
